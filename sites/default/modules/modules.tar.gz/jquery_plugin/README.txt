// $Id: README.txt,v 1.1.4.4 2008/06/23 18:38:39 mfb Exp $

The jquery_plugin module allows you to load miscellaneous jQuery plugins 
from any module by calling the jquery_plugin_add($plugin) function; for 
example, jquery_plugin_add('validate') would load the validation plugin.
	
More information about jQuery plugins can be found at 
http://plugins.jquery.com/project/Plugins
