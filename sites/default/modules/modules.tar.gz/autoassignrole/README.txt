; $Id $

Auto Assign Role
================================================================================

This module automatically assigns new users to a specific role when the user 
initially signs up for their account. It was written in response to a question 
on the support mailing list ... The list asked that it be submitted as a module
 so here it is.

How to use
--------------------------------------------------------------------------------

1. Activate the Module
3. Set permissions admin >> user >> access
2. Go into admin >> settings >> autoassignrole and enter the role you want the 
   new users to have.  You have to type the role correctly or it will not work.