; $Id: README.txt,v 1.1.2.4 2009/06/04 18:57:59 yched Exp $

Ongoing work on the multigroup module has moved to the experimental
CCK 3.0 branch.
